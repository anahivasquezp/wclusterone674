package com.modelo.jdbcdao;

import com.modelo.dao.GenericDAO;
import com.modelo.entidades.Persona;

public class JDBCGenericDAO<T,ID> implements GenericDAO<T, ID> {

	
	@Override
	public void create(T instancia) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void update(T instancia) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void delete(T instancia) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Persona getById(ID id) {
		// TODO Auto-generated method stub
		return null;
	}

}
